delete From gestion_setlist_db.morceaux where MorceauId>=1;
ALTER TABLE gestion_setlist_db.morceaux AUTO_INCREMENT = 1;