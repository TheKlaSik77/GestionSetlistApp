namespace GestionSetlistApp.DTOs.MorceauDTOs
{
    public record MorceauPatchYoutubeDTO
    {
        public required string LienYoutube { get; set; }
    }
}