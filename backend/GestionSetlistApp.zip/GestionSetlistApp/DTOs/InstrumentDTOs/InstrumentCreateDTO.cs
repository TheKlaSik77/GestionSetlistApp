namespace GestionSetlistApp.DTOs.InstrumentDTOs
{
    public record InstrumentCreateDTO
    {
        public required string Nom { get; set; }
    }
}