namespace GestionSetlistApp.DTOs.SetlistDTOs.MembreSetlistDTOs
{
    public record MembreSetlistCreateDTO
    {
        public required int MembreId { get; set; }
    }
}