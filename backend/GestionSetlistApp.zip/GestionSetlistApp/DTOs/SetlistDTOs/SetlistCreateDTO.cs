namespace GestionSetlistApp.DTOs.SetlistDTOs
{
    public record SetlistCreateDTO
    {
        public required string Nom { get; set; }
    }
}