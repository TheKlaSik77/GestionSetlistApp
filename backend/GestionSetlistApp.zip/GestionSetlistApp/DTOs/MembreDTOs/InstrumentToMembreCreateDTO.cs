namespace GestionSetlistApp.DTOs.MembreDTOs
{
    public record InstrumentToMembreCreateDTO
    {
        public required int InstrumentId;
    }
}