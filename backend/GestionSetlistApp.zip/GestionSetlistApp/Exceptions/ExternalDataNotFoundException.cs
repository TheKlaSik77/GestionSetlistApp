namespace GestionSetlistApp.Exceptions
{
    public class ExternalDataNotFoundException : Exception
    {
        public ExternalDataNotFoundException() { }

    }
}
