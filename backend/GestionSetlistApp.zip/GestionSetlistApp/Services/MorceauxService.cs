using GestionSetlistApp.DTOs.MorceauxDTOs;
using GestionSetlistApp.DTOs.MorceauSetlistsDTOs;
using GestionSetlistApp.Repositories;
using GestionSetlistApp.Models;

namespace GestionSetlistApp.Services
{
    public class MorceauxService(IMorceauxRepository morceauxRepository) : IMorceauxService
    {
        private readonly IMorceauxRepository _repository = morceauxRepository;

        public async Task<List<MorceauxReadDTO>> GetAllAsync()
        {
            // On passe la liste de Morceaux récupérés dans la base de données en DTO
            List<Morceau> morceaux = await _repository.GetAllAsync();

            List<MorceauxReadDTO> morceauxDTO = morceaux
            .Select(m => new MorceauxReadDTO(m.MorceauId, m.Titre, m.Artiste, m.Album, m.LienYoutube, m.DureeMorceau,
            m.MorceauSetlists?
                .Select(ms => new MorceauSetlistsReadDTO(
                    ms.MorceauId,
                    ms.Setlist.NomSetlist,
                    ms.Position)).ToList() ?? new()
                ))
            .ToList();

            return morceauxDTO;
        }

        public async Task AddMorceauAsync(MorceauxCreateDTO morceauDTO)
        {
            // On récupère un DTO, on en fait un Morceau (model) et on le met dans AddAsync du Repository
            Morceau morceau = new()
            {
                Titre = morceauDTO.Titre,
                Artiste = morceauDTO.Artiste,
                Album = morceauDTO.Album,
                LienYoutube = morceauDTO.LienYoutube,
                DureeMorceau = morceauDTO.DureeMorceau
            };
            await _repository.AddMorceauAsync(morceau);
        }

        public async Task AddMorceauxAsync(IEnumerable<MorceauxCreateDTO> morceauxCreateDTO)
        {
            List<Morceau> morceaux = [];
            foreach (var morceauDTO in morceauxCreateDTO)
            {
                var morceau = new Morceau
                {
                    Titre = morceauDTO.Titre,
                    Artiste = morceauDTO.Artiste,
                    Album = morceauDTO.Album,
                    LienYoutube = morceauDTO.LienYoutube,
                    DureeMorceau = morceauDTO.DureeMorceau
                };

                morceaux.Add(morceau);
            }
            await _repository.AddMorceauxAsync(morceaux);

        }

        public async Task<Morceau> GetMorceauAsync(int morceauId)
        {
            return await _repository.GetMorceauAsync(morceauId);
        }

        public async Task DeleteAllAsync()
        {
            await _repository.DeleteAllAsync();
        }
        
        
    }
}
    